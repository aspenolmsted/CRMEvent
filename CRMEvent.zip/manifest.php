<?php

$manifest = [
    'acceptable_sugar_versions' => [
        '^6\.5\.[0-9]+$',
        '^7\.[0-9]+\.[0-9]+$',
        '^8\.[0-9]+\.[0-9]+$',
    ],
    'acceptable_sugar_flavors' => ['CE'],
    'readme' => '',
    'key' => 'ev',
    'author' => 'Aspen Olmsted',
    'description' => 'Event Ticketing, Registration, and Interactive Venue Seating Map extension for SuiteCRM (extends FP_events with ev_TicketTypes, ev_Registrations, ev_Venues, ev_VenueSeats, and ev_EventSeats).',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'CRMEvent',
    'published_date' => '2026-11-27 00:00:00',
    'type' => 'module',
    'version' => '2.0.21',
];

$installdefs = [
    'id' => 'CRMEvent_v2_0_0',
    'beans' => [
        [
            'module' => 'ev_Venues',
            'class' => 'ev_Venues',
            'path' => 'modules/ev_Venues/ev_Venues.php',
            'tab' => true,
        ],
        [
            'module' => 'ev_VenueSeats',
            'class' => 'ev_VenueSeats',
            'path' => 'modules/ev_VenueSeats/ev_VenueSeats.php',
            'tab' => false,
        ],
        [
            'module' => 'ev_EventSeats',
            'class' => 'ev_EventSeats',
            'path' => 'modules/ev_EventSeats/ev_EventSeats.php',
            'tab' => true,
        ],
        [
            'module' => 'ev_TicketTypes',
            'class' => 'ev_TicketTypes',
            'path' => 'modules/ev_TicketTypes/ev_TicketTypes.php',
            'tab' => true,
        ],
        [
            'module' => 'ev_Registrations',
            'class' => 'ev_Registrations',
            'path' => 'modules/ev_Registrations/ev_Registrations.php',
            'tab' => true,
        ],
    ],
    'copy' => [
        [
            'from' => '<basepath>/modules/ev_Venues',
            'to' => 'modules/ev_Venues',
        ],
        [
            'from' => '<basepath>/modules/ev_VenueSeats',
            'to' => 'modules/ev_VenueSeats',
        ],
        [
            'from' => '<basepath>/modules/ev_EventSeats',
            'to' => 'modules/ev_EventSeats',
        ],
        [
            'from' => '<basepath>/modules/ev_TicketTypes',
            'to' => 'modules/ev_TicketTypes',
        ],
        [
            'from' => '<basepath>/modules/ev_Registrations',
            'to' => 'modules/ev_Registrations',
        ],
        [
            'from' => '<basepath>/custom/Extension/application/Ext/EntryPointRegistry/crmevent_publicmap.php',
            'to' => 'custom/Extension/application/Ext/EntryPointRegistry/crmevent_publicmap.php',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/FP_events/Ext/Vardefs/ev_event_registration_fields.php',
            'to' => 'custom/Extension/modules/FP_events/Ext/Vardefs/ev_event_registration_fields.php',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/FP_events/Ext/Layoutdefs/ev_event_subpanels.php',
            'to' => 'custom/Extension/modules/FP_events/Ext/Layoutdefs/ev_event_subpanels.php',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/Vardefs/ev_contact_registrations_rel.php',
            'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/ev_contact_registrations_rel.php',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/Layoutdefs/ev_contact_subpanels.php',
            'to' => 'custom/Extension/modules/Contacts/Ext/Layoutdefs/ev_contact_subpanels.php',
        ],
    ],
    'language' => [
        [
            'from' => '<basepath>/custom/Extension/application/Ext/Language/en_us.ev_events.php',
            'to_module' => 'application',
            'language' => 'en_us',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/FP_events/Ext/Language/en_us.ev_events.php',
            'to_module' => 'FP_events',
            'language' => 'en_us',
        ],
        [
            'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/Language/en_us.ev_events.php',
            'to_module' => 'Contacts',
            'language' => 'en_us',
        ],
    ],
    'logic_hooks' => [
        [
            'module' => 'FP_events',
            'hook' => 'after_save',
            'order' => 10,
            'description' => 'Clone Venue Seats into Event Seats when a Venue is attached to an Event',
            'file' => 'modules/ev_Venues/ev_EventVenueHooks.php',
            'class' => 'ev_EventVenueHooks',
            'function' => 'syncVenueSeatsToEvent',
        ],
        [
            'module' => 'ev_Registrations',
            'hook' => 'before_save',
            'order' => 10,
            'description' => 'Auto-generate confirmation code and QR check-in token on registration save',
            'file' => 'modules/ev_Registrations/ev_RegistrationsHooks.php',
            'class' => 'ev_RegistrationsHooks',
            'function' => 'beforeSaveRegistration',
        ],
        [
            'module' => 'ev_Registrations',
            'hook' => 'after_save',
            'order' => 10,
            'description' => 'Roll up ticket quantities sold, event remaining seats, sync native attendee link, and reserve assigned seat',
            'file' => 'modules/ev_Registrations/ev_RegistrationsHooks.php',
            'class' => 'ev_RegistrationsHooks',
            'function' => 'afterSaveRegistration',
        ],
        [
            'module' => 'ev_Registrations',
            'hook' => 'after_delete',
            'order' => 10,
            'description' => 'Recalculate ticket quantities sold, event remaining seats, and release assigned seat after deletion',
            'file' => 'modules/ev_Registrations/ev_RegistrationsHooks.php',
            'class' => 'ev_RegistrationsHooks',
            'function' => 'afterDeleteRegistration',
        ],
    ],
];